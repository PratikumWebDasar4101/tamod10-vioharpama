<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register</title>
</head>
<body>
  <h2>Registrasi</h2>
  <form action="submit.php" method="post">
    <table cellpadding="10">
      <tr>
        <td><input type="text" name="nim" placeholder="NIM"></td>
      </tr>
      <tr>
        <td><input type="text" name="username" placeholder="Username"></td>
      </tr>
      <tr>
        <td><input type="password" name="password" placeholder="Password"></td>
      </tr>
      <tr>
        <td><input type="submit" name="submit" value="Register"></td>
      </tr>
    </table>
  </form>
</body>
</html>
